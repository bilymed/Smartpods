export enum Department {
  IT = "IT",
  Marketing = "Marketing",
  Accounting = "Accounting",
  Finance = "Finance",
  Engineering = "Engineering",
  Sales = "Sales",
  HumanResources = "Human Resources",
  Logistics = "Business Development",
  Production = "Production",
  Training = "Training"
}

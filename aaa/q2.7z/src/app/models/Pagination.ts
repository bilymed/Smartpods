export class Pagination<T> {
  data: T[]
  count: number
}
